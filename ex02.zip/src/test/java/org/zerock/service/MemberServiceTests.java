package org.zerock.service;

import static org.junit.Assert.assertNotNull;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.log;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.zerock.domain.MemberVO;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j
public class MemberServiceTests {

	
	   @Setter(onMethod_ = @Autowired)
	   private MemberService service;
	   
	   @Test
	   public void testExist() {
		   log.info("서비스성공:" + service);
		   assertNotNull(service);
	   }
	   
	   @Test
	   public void testRegister() {
		   
		   MemberVO member = new MemberVO();
		   member.setId("eee");
		   member.setPassword("1234");
		   member.setName("용");
		   member.setPhone("010-8888-9999");
		   
		   service.register(member);
		   
		   log.info("생성된 게시물의 아이디: " + member.getId());
		   
	   }
	   
	   @Test
	   public void testGetList() {
		   service.getList().forEach(member -> log.info(member));
	   }
	   
	   @Test
	   public void testGet() {
		   log.info(service.get("www"));
	   }
	   
	   @Test
	   public void testDelete() {
		   log.info("REMOVE RESULT:" + service.remove("www"));
	   }
	   @Test
	   public void testUpdate() {
		   MemberVO member = service.get("eee");
		   if(member == null) {
			   return;
		   }
		   member.setName("수정");
		   log.info("modify result:" + service.modify(member));
	   }
}
