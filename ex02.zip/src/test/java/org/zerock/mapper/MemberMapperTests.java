package org.zerock.mapper;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.zerock.domain.MemberVO;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j
public class MemberMapperTests {

	
	   @Setter(onMethod_ = @Autowired )
	   private MemberMapper mapper;
	   
	   @Test
	   public void testGetList() {
		   mapper.getList().forEach(member -> log.info(member));
	   }
	   
	   @Test
	   public void testInsert() {
		   MemberVO member = new MemberVO();
		   member.setId("www");
		   member.setPassword("1234");
		   member.setName("영희");
		   member.setPhone("010-2222-2222");
		   
		   mapper.insert(member);
		   
		   log.info(member);
	   }
	   
		
		/*
		 * @Test public void testinsertSelectKey() { MemberVO board = new MemberVO();
		 * board.setTitle("새로 작성하는글2"); board.setContent("새로 작성하는 내용2");
		 * board.setWriter("newbie");
		 * 
		 * mapper.insert(board);
		 * 
		 * log.info(board); }
		 */
		  @Test public void testRead() {
		  
		  MemberVO member = mapper.read("qqq");
		  
		  log.info(member); }
		  
		  @Test public void testDelete() {
		  
		  log.info("Delete Count:"+mapper.delete("qqq")); }
		  
		  @Test public void testUpdate() {
		  
		  MemberVO member = new MemberVO(); 
		  member.setPassword("2222");
		  member.setName("내용");
		  member.setPhone("010-7777-7777");
		  
		  int count = mapper.update(member); 
		  log.info("update count:" + count); 
		  
}
		 
}
